/**
 * 
 */
/**
 * 
 */
module Proyecto {
	requires gson;
	requires org.json;
}